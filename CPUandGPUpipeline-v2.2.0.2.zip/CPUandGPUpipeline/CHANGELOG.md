# Changelog

## [2.1.0] - 2026-11-11

### Adicionado
- Processamento vetorial real: multiplicacao dos elementos por um fator de escala.
- Kernel OpenCL compilado em tempo de inicializacao.
- Worker thread consumindo tarefas da fila SPSC.
- Modo hibrido: divide lotes grandes entre CPU nativa e GPU OpenCL em paralelo (limiar inicial de 8.192 valores).
- Fallback para CPU nativa quando OpenCL nao esta disponivel ou falha.
- API C para processamento com buffer de saida, consulta de backend e versao.
- Interface Python com argumentos de linha de comando e testes automatizados.
- Build sem dependencia obrigatoria de OpenCL; deteccao opcional via pkg-config.

### Corrigido
- README agora descreve o que o codigo realmente executa; nao afirma implementar Ray Tracing.
- Tratamento de entrada vazia, ponteiros nulos, escala nao finita e limite de elementos.
- Gerenciamento de recursos OpenCL e encerramento do worker.

## [2.0.2] - 2026-10-30
- Versao anterior: inicializacao OpenCL e transferencia de dados, sem kernel de processamento.


## [2.2.0] - 2026-11-11

### Adicionado
- API assincrona com `submeterGeometria` e `coletarGeometria`, IDs de tarefa e limite de 64 tarefas pendentes.
- `PipelineSession` em Python para submeter varias tarefas antes de coletar os resultados.

### Corrigido
- Estado do backend publicado por `std::atomic`, sem leitura concorrente de `std::string`.
- Identificação explícita dos modos `CPU`, `GPU`, `OPENCL_CPU` e `HYBRID`.
- Thread auxiliar do modo híbrido protegida por RAII para garantir `join()` durante exceções.
- Exceções impedidas de atravessar a fronteira da API C; erros de processamento retornam códigos.
- Fallback integral para CPU quando a execução OpenCL falha.
- Backpressure da fila com espera baseada em predicado, evitando perda de notificacao; limite de tarefas pendentes retorna erro em vez de bloquear indefinidamente.

### Observações
- A API de processamento continua síncrona e serializada por produtor. A fila SPSC não representa ainda uma API de submissão assíncrona multi-tarefa.
- Execução real OpenCL depende de SDK/runtime e dispositivo compatível; o fallback CPU pode ser testado sem GPU.
